package Member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Professor_cey extends MemberDAO{
	private Connection connection = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null; // 스트링 리스트라고 생각하기.
	
	Scanner scanner = new Scanner(System.in);
	
	private final String PROFINSERT = "INSERT INTO PROFESSOR values(?,?,?,?,?,?,?,?";
	private final String LOGIN = "SELECT Pw FROM MEMBER WHERE ID = ?";
	private final String DELETE = "DELETE MEMBER WHERE ID = ?"
	private final String SELECTALL = "SELECT * FROM MEMBER";
	private final String SEARCH = "SELECT * FROM MEMBER WHERE NAME = ?";
	
	
	
    public boolean prof_insert(Professor professor) {
        try {
            connection = dbConn.getConnection();
            stmt = connection.prepareStatement(PROFINSERT);

            stmt.setString(1, professor.getID());
            stmt.setString(2, professor.getPw());
            stmt.setString(3, professor.getName());
            stmt.setString(4, professor.getEmail());
            stmt.setString(5, professor.Reg_Date());
            stmt.setString(6, professor.getMajor());
            stmt.setString(7, professor.getOffice());
            stmt.setString(8, professor.getGender());

            stmt.executeUpdate();

            System.out.println("교수 회원가입 완료.");

        } catch (SQLException e){
            e.printStackTrace();
        } finally {
            dbConn.close(stmt);
        } return true;
    }
    
    // 교수 정보 삭제
    public void prof_delete(String Id) { // String id를 넣으면, primary key 에해당하는 값을 찾아서 지운다.
        try {
            connection = dbConn.getConnection();
            stmt = connection.prepareStatement(DELETE);
            stmt.setString (1, Id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            dbConn.close(stmt);
        }
    }
    

    // 모든 멤버 목록 조회
    public List<Member> selectAll() {
        List<Member> memberList = new ArrayList<>(); // 멤버 배열 선언
        try {
            connection = dbConn.getConnection();
            stmt = connection.prepareStatement(SELECTALL); // 컨트롤러에 스튜던트의 이름(멤버)가져와서 stmt에 넣는다(대입)
            while (rs.next()) { // for문처럼 rs에 해당하는 부문을 정찰한다.
                Member m = new Member(rs.getString("Id"), rs.getString("Pw"), // 암기 
                        rs.getString("Name"), rs.getString("Email"),
                        rs.getString("Reg_Date"), rs.getString("Gender")); // toString
                memberList.add(m); // 멤버 배열에 삽입
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            dbConn.close(stmt);
            dbConn.close(rs);
        }
        return memberList;
    }   // 교수 리스트업으로 해보기.


    // 로그인
    public int login(String Id, String Pw) {
        try {
            connection = dbConn.getConnection();
            stmt = connection.prepareStatement(LOGIN);
            stmt.setString(1, Id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                if (rs.getString(1).contentEquals(Pw)) {
                    // System.out.println("로그인 성공");
                    return 1;
                }
                else {
                    // System.out.println("로그인 실패, 비밀번호 오류");
                    return 0;
                }
            }
            // System.out.println("로그인 실패, 존재하지 않는 아이디입니다");
            return -1;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    return -2; // 커넥션부터 틀렸을 때 - 오류를 알기 위해서 return에 숫자로 표현 
    }

    
    
    public Professor getInfo(String id) {
        Professor prof = new Professor();
        
         try {
            connection = dbConn.getConnection();
            stmt = connection.prepareStatement("SELECT * FROM Professor WHERE ID = ?");
            stmt.setString(1, id);
            rs = stmt.executeQuery();
            
            if(rs.next()) {
               prof.setId(rs.getString(1));
                prof.setPw(rs.getString(2));
                prof.setName(rs.getString(3));
                prof.setEmail(rs.getString(4));
                prof.setReg_Date(rs.getString(5));
                prof.setMajor(rs.getString(6));
                prof.setOffice(rs.getString(7));
                prof.setGender(rs.getString(8));
            }else
            {}

            if(rs != null) rs.close();
            if(stmt != null) stmt.close();
            if(connection != null) connection.close();
          } catch (SQLException e) {
              e.printStackTrace();
          }

        return prof;
      }
}
    	